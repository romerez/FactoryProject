
export const JobTitle = {
    "Customer Service": 0,
    "Storage": 1,
    "Office": 2,
}